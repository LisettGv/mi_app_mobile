package cl.mlj.app1.model

//data class Counter(val value: Int = 0)


data class Counter(
    val value: Int = 0
)
